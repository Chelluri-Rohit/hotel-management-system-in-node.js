# hostel-management-system-node
Hostel management system made using nodejs
